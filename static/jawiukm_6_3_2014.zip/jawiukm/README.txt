1. Add Arabic(Saudi Arabia) keyboard using control panel.
2. Run "setup.exe". This will install JawiUKM keyboard layout 
to your computer.
3. Jawi keyboard is under Arabic.

zamri@ftsm.ukm.my

Developer Notes.
1. Download MSKLC is you need your own layout.
2. Use unicode encoding. Please refer 
https://en.wikipedia.org/wiki/Jawi_alphabet.

